import './App.css';
import './components/MainContainer';
import MainContainer from './components/MainContainer';
function App() {
  return (
    <div>
      <MainContainer></MainContainer>
    </div>
  );
}

export default App;
